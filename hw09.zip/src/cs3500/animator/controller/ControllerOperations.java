package cs3500.animator.controller;


/**
 * Controller that dictates actions to the model and the view.
 */
public interface ControllerOperations {

}
